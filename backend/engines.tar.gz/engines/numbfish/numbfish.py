#!/usr/bin/env python3 -u
from __future__ import print_function
import re
import sys
import time
import os
from itertools import count
from collections import namedtuple
import chess
import chess.polyglot
import numpy as np

os.environ["CUDA_VISIBLE_DEVICES"] = ""

sys.path.append("/app/backend/engines/numbfish")
try:
    from nnue_eval import *
except ImportError as e:
    print(f"Error importing nnue_eval: {str(e)}", file=sys.stderr)
    sys.exit(1)

import tools

OPENING_BOOK_PATH = "/app/backend/engines/numbfish/Perfect2021.bin"

def parse(c: str) -> int:
    """Преобразует UCI-нотацию (например, 'd2') в индекс на доске (например, 64)."""
    fil, rank = c[0], c[1]
    file_idx = ord(fil) - ord('a')
    rank_idx = 8 - int(rank)
    return 21 + file_idx + rank_idx * 10

def render(i: int) -> str:
    """Преобразует индекс на доске (например, 64) в UCI-нотацию (например, 'd2')."""
    rank_idx, file_idx = divmod(i - 21, 10)
    return chr(ord('a') + file_idx) + str(8 - rank_idx)

piece = {'P': 100, 'N': 280, 'B': 320, 'R': 479, 'Q': 929, 'K': 60000}
pst = {
    'P': (
        0, 0, 0, 0, 0, 0, 0, 0,
        78, 83, 86, 73, 102, 82, 85, 90,
        7, 29, 21, 44, 40, 31, 44, 7,
        -17, 16, -2, 15, 14, 0, 15, -13,
        -26, 3, 10, 9, 6, 1, 0, -23,
        -22, 9, 5, -11, -10, -2, 3, -19,
        -31, 8, -7, -37, -36, -14, 3, -31,
        0, 0, 0, 0, 0, 0, 0, 0
    ),
    'N': (
        -66, -53, -75, -75, -10, -55, -58, -70,
        -3, -6, 100, -36, 4, 62, -4, -14,
        10, 67, 1, 74, 73, 27, 62, -2,
        24, 24, 45, 37, 33, 41, 25, 17,
        -1, 5, 31, 21, 22, 35, 2, 0,
        -18, 10, 13, 22, 18, 15, 11, -14,
        -23, -15, 2, 0, 2, 0, -23, -20,
        -74, -23, -26, -24, -19, -35, -22, -69
    ),
    'B': (
        -59, -78, -82, -76, -23, -107, -37, -50,
        -11, 20, 35, -42, -39, 31, 2, -22,
        -9, 39, -32, 41, 52, -10, 28, -14,
        25, 17, 20, 34, 26, 25, 15, 10,
        13, 10, 17, 23, 17, 16, 0, 7,
        14, 25, 24, 15, 8, 25, 20, 15,
        19, 20, 11, 6, 7, 6, 20, 16,
        -7, 2, -15, -12, -14, -15, -10, -10
    ),
    'R': (
        35, 29, 33, 4, 37, 33, 56, 50,
        55, 29, 56, 67, 55, 62, 34, 60,
        19, 35, 28, 33, 45, 27, 25, 15,
        0, 5, 16, 13, 18, -4, -9, -6,
        -28, -35, -16, -21, -13, -29, -46, -30,
        -42, -28, -42, -25, -25, -35, -26, -46,
        -53, -38, -31, -26, -29, -43, -44, -53,
        -30, -24, -18, 5, -2, -18, -31, -32
    ),
    'Q': (
        6, 1, -8, -104, 69, 24, 88, 26,
        14, 32, 60, -10, 20, 76, 57, 24,
        -2, 43, 32, 60, 72, 63, 43, 2,
        1, -16, 22, 17, 25, 20, -13, -6,
        -14, -15, -2, -5, -1, -10, -20, -22,
        -30, -6, -13, -11, -16, -11, -16, -27,
        -36, -18, 0, -19, -15, -15, -21, -38,
        -39, -30, -31, -13, -31, -36, -34, -42
    ),
    'K': (
        4, 54, 47, -99, -99, 60, 83, -62,
        -32, 10, 55, 56, 56, 55, 10, 3,
        -62, 12, -57, 44, -67, 28, 37, -31,
        -55, 50, 11, -4, -19, 13, 0, -49,
        -55, -43, -52, -28, -51, -47, -8, -50,
        -47, -42, -43, -79, -64, -32, -29, -32,
        -4, 3, -14, -50, -57, -18, 13, 4,
        17, 30, -3, -14, 6, -1, 40, 18
    ),
}

piece_weights = {}
for k, table in pst.items():
    padrow = lambda row: (0,) + tuple(x + piece[k] for x in row) + (0,)
    pst[k] = sum((padrow(table[i*8:i*8+8]) for i in range(8)), ())
    piece_weights[k] = (0,) * 20 + pst[k] + (0,) * 20

A1, H1, A8, H8 = 91, 98, 21, 28
A2, A7 = 81, 31
initial = (
    '         \n'
    '         \n'
    ' rnbqkbnr\n'
    ' pppppppp\n'
    ' ........\n'
    ' ........\n'
    ' ........\n'
    ' ........\n'
    ' PPPPPPPP\n'
    ' RNBQKBNR\n'
    '         \n'
    '         \n'
)

N, E, S, W = -10, 1, 10, -1
directions = {
    'P': (N, N+N, N+W, N+E),
    'p': (S, S+S, S+W, S+E),
    'N': (N+N+E, E+N+E, E+S+E, S+S+E, S+S+W, W+S+W, W+N+W, N+N+W),
    'n': (N+N+E, E+N+E, E+S+E, S+S+E, S+S+W, W+S+W, W+N+W, N+N+W),
    'B': (N+E, S+E, S+W, N+W),
    'b': (N+E, S+E, S+W, N+W),
    'R': (N, E, S, W),
    'r': (N, E, S, W),
    'Q': (N, E, S, W, N+E, S+E, S+W, N+W),
    'q': (N, E, S, W, N+E, S+E, S+W, N+W),
    'K': (N, E, S, W, N+E, S+E, S+W, N+W),
    'k': (N, E, S, W, N+E, S+E, S+W, N+W)
}

MATE_LOWER = piece['K'] - 10*piece['Q']
MATE_UPPER = piece['K'] + 10*piece['Q']

TABLE_SIZE = 1e7

QS_LIMIT = 219
EVAL_ROUGHNESS = 13
DRAW_TEST = True
OPENING_BOOK = False

class Position(namedtuple('Position', 'board score wc bc ep kp turn')):
    """Представляет состояние шахматной позиции."""
    def gen_moves(self):
        """Генерирует все возможные ходы для текущей позиции."""
        is_white = self.turn
        moves = []
        for i, p in enumerate(self.board):
            if i < 20 or i > 99: continue
            if is_white and not p.isupper(): continue
            if not is_white and not p.islower(): continue
            piece_type = p
            if piece_type not in directions:
                continue
            for d in directions[piece_type]:
                for j in count(i+d, d):
                    if j < 20 or j > 99: break
                    q = self.board[j]
                    if q.isspace(): break
                    if is_white and q.isupper(): break
                    if not is_white and q.islower(): break
                    if piece_type in ('P', 'p'):
                        pawn_dir = N if is_white else S
                        pawn_double = N+N if is_white else S+S
                        pawn_capture_left = N+W if is_white else S+W
                        pawn_capture_right = N+E if is_white else S+E
                        if d in (pawn_dir, pawn_double) and q != '.': break
                        if d == pawn_double:
                            start_rank = A2 if is_white else A7
                            if (i < start_rank or i > start_rank+7) or self.board[i+pawn_dir] != '.':
                                break
                        if d in (pawn_capture_left, pawn_capture_right):
                            if q == '.' and j != self.ep:
                                break
                    moves.append((i, j))
                    if piece_type in ('P', 'p', 'N', 'n', 'K', 'k') or (is_white and q.islower()) or (not is_white and q.isupper()): break
                    if i == A1 and self.board[j+E] == 'K' and self.wc[0] and is_white: moves.append((j+E, j+W))
                    if i == H1 and self.board[j+W] == 'K' and self.wc[1] and is_white: moves.append((j+W, j+E))
                    if i == A8 and self.board[j+E] == 'k' and self.bc[0] and not is_white: moves.append((j+E, j+W))
                    if i == H8 and self.board[j+W] == 'k' and self.bc[1] and not is_white: moves.append((j+W, j+E))
        return moves

    def rotate(self):
        """Поворачивает доску, сохраняя en passant."""
        return Position(
            self.board[::-1].swapcase(), -self.score, self.bc, self.wc,
            119-self.ep if self.ep else 0,
            119-self.kp if self.kp else 0, not self.turn)

    def nullmove(self):
        """Выполняет нулевой ход, очищая en passant и king passant."""
        return Position(
            self.board[::-1].swapcase(), -self.score,
            self.bc, self.wc, 0, 0, not self.turn)

    def move(self, move, promotion_piece: str = 'Q'):
        """Применяет ход к текущей позиции."""
        i, j = move
        if not (0 <= i < 120 and 0 <= j < 120):
            raise IndexError(f"Invalid move indices: {i} to {j}")
        p, q = self.board[i], self.board[j]
        put = lambda board, i, p: board[:i] + p + board[i+1:]
        board = self.board
        wc, bc, ep, kp = self.wc, self.bc, 0, 0
        score = self.score + self.value(move)
        board = put(board, j, board[i])
        board = put(board, i, '.')
        if i == A1: wc = (False, wc[1])
        if i == H1: wc = (wc[0], False)
        if j == A8: bc = (bc[0], False)
        if j == H8: bc = (False, bc[1])
        if p in ('K', 'k'):
            wc = (False, False) if p == 'K' else wc
            bc = (False, False) if p == 'k' else bc
            if abs(j-i) == 2:
                kp = (i+j)//2
                board = put(board, A1 if j < i else H1, '.') if p == 'K' else board
                board = put(board, A8 if j < i else H8, '.') if p == 'k' else board
                board = put(board, kp, 'R' if p == 'K' else 'r')
        if p in ('P', 'p'):
            if (A8 <= j <= H8 and p == 'P') or (A1 <= j <= H1 and p == 'p'):
                promotion = promotion_piece.upper() if p == 'P' else promotion_piece.lower()
                board = put(board, j, promotion)
            if j - i == 2*N and p == 'P':
                ep = i + N
            if j - i == 2*S and p == 'p':
                ep = i + S
            if j == self.ep:
                board = put(board, j+S if p == 'P' else j+N, '.')
        return Position(board, score, wc, bc, ep, kp, not self.turn)

    def value(self, move):
        """Вычисляет ценность хода для оценки позиции."""
        i, j = move
        p, q = self.board[i], self.board[j]
        p_upper = p.upper()
        q_upper = q.upper() if q.islower() or q.isupper() else q
        if p.islower():
            i = 119 - i
            j = 119 - j
        score = pst[p_upper][j] - pst[p_upper][i]
        if q.islower() or q.isupper():
            score += pst[q_upper][119 - j]
        if abs(j - self.kp) < 2:
            score += pst['K'][119 - j]
        if p_upper == 'K' and abs(i - j) == 2:
            score += pst['R'][(i + j) // 2]
            score -= pst['R'][A1 if j < i else H1]
        if p_upper == 'P':
            if A8 <= j <= H8:
                score += pst['Q'][j] - pst['P'][j]
            if j == self.ep:
                score += pst['P'][119 - (j + S)]
        return score

class Searcher:
    """Класс для поиска лучшего хода в шахматной позиции."""
    def __init__(self):
        """Инициализирует объект поисковика."""
        self.tp_score = {}
        self.tp_move = {}
        self.history = set()
        self.nodes = 0
        self.use_classical = False

    def bound(self, pos, gamma, depth, kings, accum_root, accum_up, pos_prev, move_prev, root=True):
        """Оценивает позицию с использованием алгоритма alpha-beta."""
        self.nodes += 1
        depth = max(depth, 0)
        if pos.score <= -MATE_LOWER:
            return -MATE_UPPER
        if not root and pos.board in self.history:
            return 0
        entry = self.tp_score.get((pos, depth, root), Entry(-MATE_UPPER, MATE_UPPER))
        if entry.lower >= gamma and (not root or self.tp_move.get(pos) is not None):
            return entry.lower
        if entry.upper < gamma:
            return entry.upper
        def moves():
            if depth > 0 and not root and any(c in pos.board for c in 'RBNQ'):
                yield None, -self.bound(pos.nullmove(), 1-gamma, depth-3, kings, accum_root, accum_up, pos, None, root=False)
            if depth == 0:
                if not self.use_classical:
                    interpreter.set_tensor(input_details[0]["index"], accum_root)
                    interpreter.invoke()
                    score = ((((interpreter.get_tensor(output_details[0]["index"]))[0][0])// 16) * 100) // 208
                else:
                    score = pos.score
                yield None, score
            killer = self.tp_move.get(pos)
            if killer and (depth > 0 or pos.value(killer) >= QS_LIMIT):
                move_king_t = pos.board[killer[0]] in 'Kk'
                if not numbfish.can_kill_king(pos.move(killer)):
                    yield killer, -self.bound(pos.move(killer), 1-gamma, depth-1, kings, accum_root, move_king_t, pos, killer, root=False)
            for move in sorted(pos.gen_moves(), key=pos.value, reverse=True):
                if depth > 0 or pos.value(move) >= QS_LIMIT:
                    move_king_t = pos.board[move[0]] in 'Kk'
                    if not numbfish.can_kill_king(pos.move(move)):
                        yield move, -self.bound(pos.move(move), 1-gamma, depth-1, kings, accum_root, move_king_t, pos, move, root=False)
        best = -MATE_UPPER
        cur_accum = np.empty([1, 512], dtype=np.float32)
        if not self.use_classical:
            if accum_up:
                board = chess.Board(fen=tools.renderFEN(pos))
                turn = board.turn
                kings = (board.king(turn), board.king(not turn)) if turn else (board.king(not turn), board.king(turn))
                ind = get_halfkp_indices(board)
                cur_accum[0][:256] = np.sum(transformer_weights[ind[0]], axis=0)
                cur_accum[0][256:] = np.sum(transformer_weights[ind[1]], axis=0)
                cur_accum[0][:256] += transformer_bias
                cur_accum[0][256:] += transformer_bias
                accum_up = False
            else:
                if move_prev:
                    move_chess = tools.chess_move_from_to(pos_prev, move_prev)
                    turn = False if pos_prev.board.startswith('\n') else True
                    cur_accum = accum_update(accum_root, turn, move_chess, kings)
                else:
                    cur_accum[0][0:256] = accum_root[0][256:]
                    cur_accum[0][256:] = accum_root[0][0:256]
        for move, score in moves():
            best = max(best, score)
            if best >= gamma:
                if len(self.tp_move) > TABLE_SIZE: self.tp_move.clear()
                self.tp_move[pos] = move
                break
        if best < gamma and best < 0 and depth > 0:
            is_dead = lambda pos: any(pos.value(m) >= MATE_LOWER for m in pos.gen_moves())
            if all(is_dead(pos.move(m)) for m in pos.gen_moves()):
                in_check = is_dead(pos.nullmove())
                best = -MATE_UPPER if in_check else 0
        if len(self.tp_score) > TABLE_SIZE: self.tp_score.clear()
        if best >= gamma:
            self.tp_score[pos, depth, root] = Entry(best, entry.upper)
        if best < gamma:
            self.tp_score[pos, depth, root] = Entry(entry.lower, best)
        return best

    def search(self, pos, movetime, use_classical=False, history=()):
        """Ищет лучший ход для заданной позиции."""
        self.nodes = 0
        if DRAW_TEST:
            self.history = history
            self.tp_score.clear()
        self.use_classical = use_classical
        global OPENING_BOOK
        if OPENING_BOOK:
            try:
                with chess.polyglot.open_reader(OPENING_BOOK_PATH) as reader:
                    time.sleep(0.01)
                    opening = reader.choice(chess.Board(tools.renderFEN(pos)))
                    yield opening.move, 1, True
            except Exception as e:
                OPENING_BOOK = False
        for depth in range(2, 100):
            lower, upper = -MATE_UPPER, MATE_UPPER
            while lower < upper - EVAL_ROUGHNESS:
                gamma = (lower+upper+1)//2
                score = self.bound(pos, gamma, depth, None, np.zeros([1, 512], dtype=np.float32), True, pos, None)
                if score >= gamma:
                    lower = score
                if score < gamma:
                    upper = score
            self.bound(pos, lower, depth, None, np.zeros([1, 512], dtype=np.float32), True, pos, None)
            move = self.tp_move.get(pos)
            yield depth, move, lower, False

class UCIEngine:
    """Класс для взаимодействия с шахматным движком через протокол UCI."""
    def __init__(self):
        """Инициализирует шахматный движок."""
        self.board = chess.Board()
        self.searcher = Searcher()
        self.history = [Position(initial, 0, (True, True), (True, True), 0, 0, True)]

    def uci_loop(self):
        """Обрабатывает команды UCI в цикле."""
        print("id name Numbfish")
        print("id author unknown")
        print("uciok")
        while True:
            command = input().strip()
            if command == "uci":
                print("id name Numbfish")
                print("id author unknown")
                print("uciok")
            elif command == "isready":
                print("readyok")
            elif command == "ucinewgame":
                self.board = chess.Board()
                self.history = [Position(initial, 0, (True, True), (True, True), 0, 0, True)]
            elif command.startswith("position"):
                self.set_position(command)
            elif command.startswith("go"):
                move = self.get_best_move(command)
                if move:
                    print(f"bestmove {move}")
                else:
                    print(f"No legal moves available, position FEN: {self.board.fen()}", file=sys.stderr)
            elif command == "quit":
                break

    def set_position(self, command):
        """Устанавливает позицию на доске по команде UCI."""
        parts = command.split()
        try:
            if parts[1] == "startpos":
                self.board = chess.Board()
                self.history = [Position(initial, 0, (True, True), (True, True), 0, 0, True)]
                if len(parts) > 2 and parts[2] == "moves":
                    for move in parts[3:]:
                        self.board.push_uci(move)
                        pos = self.history[-1].move((parse(move[:2]), parse(move[2:4])))
                        self.history.append(pos)
            elif parts[1] == "fen":
                fen = " ".join(parts[2:8])
                self.board = chess.Board(fen)
                turn = self.board.turn == chess.WHITE
                self.history = [Position(tools.parseFEN(fen), 0, (True, True), (True, True), 0, 0, turn)]
                if len(parts) > 8 and parts[8] == "moves":
                    for move in parts[9:]:
                        self.board.push_uci(move)
                        pos = self.history[-1].move((parse(move[:2]), parse(move[2:4])))
                        self.history.append(pos)
        except Exception as e:
            print(f"Error setting position: {str(e)}, command: {command}", file=sys.stderr)

    def get_best_move(self, command):
        """Получает лучший ход для текущей позиции."""
        movetime = 1.0
        try:
            for depth, move, score, is_book in self.searcher.search(self.history[-1], movetime, history=[p.board for p in self.history]):
                if is_book:
                    return move.uci()
                if move:
                    uci_move = render(move[0]) + render(move[1])
                    try:
                        chess_move = chess.Move.from_uci(uci_move)
                        if chess_move in self.board.legal_moves:
                            return uci_move
                        else:
                            print(f"Illegal move generated: {uci_move}", file=sys.stderr)
                    except ValueError as e:
                        print(f"Invalid move format: {uci_move}, error: {str(e)}", file=sys.stderr)
                break
            return None
        except Exception as e:
            print(f"Error in get_best_move: {str(e)}, position FEN: {self.board.fen()}", file=sys.stderr)
            return None

if __name__ == "__main__":
    engine = UCIEngine()
    engine.uci_loop()
